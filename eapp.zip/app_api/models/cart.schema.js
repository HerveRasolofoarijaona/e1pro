/**
 * Created by nokamojd on 08/09/2016.
 */
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var cartSchema = new Schema({
    owner: {
       type: Schema.Types.ObjectId,
       ref:'User'
    },
    total_price:{type:Number, default:0},
    items:[{
        item:{
            type: Schema.Types.ObjectId,
            ref:'Offer'
        },
        quantity: {type:Number, default:1},
        price: {type:Number, default:0}
    }]
});

module.exports = mongoose.model('Cart', cartSchema);