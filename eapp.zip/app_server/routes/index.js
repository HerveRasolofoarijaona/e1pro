var express = require('express');
var router = express.Router();
var passport = require('passport');
var passportConf = require('../../passport-conf');
var mongoose = require('mongoose');

require('../../app_api/models/user.schema');
require('../../app_api/models/cart.schema');
require('../../app_api/models/consultant.schema.js');
require('../../app_api/models/enterprise.schema.js');
var User = mongoose.model('User');
var Cart = mongoose.model('Cart');
var Consultant = mongoose.model('Consultant');
var Enterprise = mongoose.model('Enterprise');
var async = require('async');
var othersCrtlr = require('../controllers/others.controller');
var catalogsCtrlr = require('../controllers/catalogs.controller');
var usersCtrlr = require('../controllers/users.controller');
var authCtrlr = require('../controllers/auth.controller.js');


/* GET accueil and static pages. */
router.get('/', othersCrtlr.accueil);
router.get('/mentions-legales', othersCrtlr.mention);
router.get('/confidentialite', othersCrtlr.confidentialite);
router.get('/termes-et-conditions', othersCrtlr.termes);
router.get('/cookies', othersCrtlr.cookies);
router.get('/nous-contacter', othersCrtlr.contacter);
router.get('/a-propos', othersCrtlr.propos);
router.get('/presse', othersCrtlr.presse);
router.get('/help', othersCrtlr.help);
router.get('/denied', othersCrtlr.denied);

/* GET Reglog pages */
router.get('/signup', authCtrlr.signupPageRender);
router.get('/enterprise/signup', authCtrlr.businessSignupPageRender);
//router.post('/signup', authCtrlr.signUp);
//router.post('/signup/u1', authCtrlr.signUpCs);
//router.post('/signup/u0', authCtrlr.signUpEn);


// Sign up for enterprise user
router.post('/enterprise/signup', function (req, res, next) {
    async.waterfall([
        function(callback){
            var user = new User();
            user.company_name = req.body.businessName;
            user.first_name = req.body.firstName;
            user.last_name = req.body.lastName;
            user.qualification = req.body.position;
            user.email = req.body.email;
            user.password = req.body.password;
            user.user_role = req.body.role;
            user.profile_pic_path = user.gravatar(64);
            User.findOne({email: req.body.email}, function (err, existingUser) {
                if(existingUser){
                    req.flash('errors', 'Cet email existe déjà.');
                    return res.redirect('signup');
                } else{
                    user.save(function (err, user) {
                        if(err) return next(err);
                        callback(null, user);
                        //return res.redirect('login');
                    })
                }
            })
        },
        function(user) {
            var enterprise = new Enterprise();
            enterprise.linked_user = user._id;
            enterprise.save(function (err) {
                if(err) return next(err);
            });
            var cart = new Cart();
            cart.owner = user._id;
            cart.save(function(err) {
                if(err) return next(err);
                res.redirect('/login');
            });
        }
    ]);
});



// Sign up for consultant user
router.post('/signup', function (req, res, next) {
    async.waterfall([
        function(callback){
            var user = new User();
            user.first_name = req.body.firstName;
            user.last_name = req.body.lastName;
            user.email = req.body.email;
            user.password = req.body.password;
            user.user_role = req.body.role;
            user.profile_pic_path = user.gravatar(64);

            User.findOne({email: req.body.email}, function (err, existingUser) {
                if(existingUser){
                    req.flash('errors', 'Cet email existe déjà.');
                    return res.redirect('signup');
                } else{
                    user.save(function (err, user) {
                        if(err) return next(err);
                        callback(null, user);
                        //return res.redirect('login');
                    })
                }
            })
        },
        function(user) {
            var consultant = new Consultant();
            consultant.related_user = user._id;
            consultant.save(function (err) {
                if(err) return next(err);
            });
            var cart = new Cart();
            cart.owner = user._id;
            cart.save(function(err) {
                if(err) return next(err);
                res.redirect('login');
            });
        }
        //return res.redirect('login');
    ]);
});

// Login user directly
router.get('/login', authCtrlr.loginPageRender);
router.post('/login', passport.authenticate('local-login', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}));

router.get('/logout', authCtrlr.logOut);
router.get('/forgotten', authCtrlr.forgotten);
router.get('/renew', authCtrlr.renew);

/* GET Catalogs pages */
router.get('/offers', catalogsCtrlr.offers);
router.get('/demands', catalogsCtrlr.demands);
router.get('/consultants', catalogsCtrlr.consultants);

/* GET post details pages */
router.get('/offers/:id_offer', catalogsCtrlr.offerDetails);
//router.get('/offers/:id_offer', catalogsCtrlr.offerDetailsWithReviewsApproved);
router.get('/demands/:id_demand', catalogsCtrlr.demandDetails);
router.get('/consultants/:id_user', catalogsCtrlr.consultantDetails);

/* POST REVIEW */
router.post('/offers/:id_offer', catalogsCtrlr.postReview);

/* Add Item to cart */
router.put('/offers/:id_offer', catalogsCtrlr.addToCart);
router.post('/cart/remove', catalogsCtrlr.removeItemFromCart);

/* Get Cart page */
var cartCtrlr = require('../controllers/cart.controller');
router.get('/cart', cartCtrlr.getCart);


/* Get search pages */
var searchCtrlr = require('../controllers/search.controller');
router.post('/search', searchCtrlr.searchRequest);
router.get('/search', searchCtrlr.offersSearch);



/* GET consultants pages.
router.get('/consultants', usersCtrlr.userAll);
router.get('/consultants/consultant-details', usersCtrlr.userProfil);*/

module.exports = router;
