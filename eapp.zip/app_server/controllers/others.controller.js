/**
 * Created by nokamojd on 11/07/2016.
 */

// Accueil controller routed to the home page
module.exports.accueil = (function (req, res) {
    res.render('accueil', {title: 'Emploi1Pro | Trouvez le pro sur mesure'});
});

// help controller routed to the help page
module.exports.help = (function (req, res) {
    res.render('index', {title: 'Emploi1Pro | Aide'});
});

// mention controller routed to the mention page
module.exports.mention = (function (req, res) {
    res.render('mention', {title: 'Emploi1Pro | Mentions légales'});
});

// confidentialite controller routed to the mention page
module.exports.confidentialite = (function (req, res) {
    res.render('confidentialite', {title: 'Emploi1Pro | Confidentialité'});
});

// termes controller routed to the mention page
module.exports.termes = (function (req, res) {
    res.render('termes', {title: 'Emploi1Pro | Termes et conditions'});
});

// cookies controller routed to the mention page
module.exports.cookies = (function (req, res) {
    res.render('cookies', {title: 'Emploi1Pro | Cookies'});
});

// contacter controller routed to the mention page
module.exports.contacter = (function (req, res) {
    res.render('contacter', {title: 'Emploi1Pro | Nous contacter'});
});

// A propos controller routed to the mention page
module.exports.propos = (function (req, res) {
    res.render('propos', {title: 'Emploi1Pro | A propos'});
});

// Presse controller routed to the mention page
module.exports.presse = (function (req, res) {
    res.render('presse', {title: 'Emploi1Pro | Presse'});
});

// Accueil controller routed to the home page
module.exports.denied = (function (req, res) {
    res.render('denied-access', {title: 'Emploi1Pro | Denied Access',
    content: 'Oups! Vous n\'avez pas le droit d\'accéder à cette page. Veuillez retourner sur '});
});

module.exports.dashHomePage = (function (req, res) {
    if(!req.user) return res.redirect('/login');
    res.render('dashboard/dashboard-home', {title: 'Emploi1Pro | Dashboard'});
});