/**
 * Created by nokamojd on 28/09/2016.
 */
var mongoose = require('mongoose');
var mongoosastic = require('mongoosastic');
require('../../app_api/models/offer.schema');
var Offer = mongoose.model('Offer');
require('../../app_api/models/demand.schema');
var Demand = mongoose.model('Demand');
require('../../app_api/models/consultant.schema');
var Consultant = mongoose.model('Consultant');


module.exports.searchRequest = (function (req, res, next) {
    res.redirect('/search?q=' + req.body.q + '&section=' + req.body.section);
});


module.exports.offersSearch = (function (req, res, next) {

    if(req.query.q && req.query.section == 0){
        Demand.search({
            query_string: {query: req.query.q}
        }, function (err, results) {
            results:
            if(err) return next(err);
            var data = results.hits.hits.map(function (hit) {
                return hit;
            });
            res.render('search-in-demands', {
                query: req.query.q,
                section: req.query.section,
                data: data
            });
        });

    } else if(req.query.q && req.query.section == 1){
        Consultant.search({
            query_string: {query: req.query.q}
        }, function (err, results) {
            results:
            if(err) return next(err);
            var data = results.hits.hits.map(function (hit) {
                return hit;
            });
            res.render('search-in-consultants', {
                query: req.query.q,
                section: req.query.section,
                data: data
            });
        });

    } else if(req.query.q && req.query.section == 2){
        Offer.search({
            query_string: {query: req.query.q}
        }, function (err, results) {
            results:
            if(err) return next(err);
            var data = results.hits.hits.map(function (hit) {
                return hit;
            });
            res.render('search-in-offers', {
                query: req.query.q,
                section: req.query.section,
                data: data
            });
        });
    }
    else{
        res.redirect('/');
    }
});
