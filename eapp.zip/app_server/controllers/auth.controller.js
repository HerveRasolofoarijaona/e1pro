/**
 * Created by nokamojd on 12/07/2016.
 */
var request = require('request');
var methodOverride = require('method-override');
var passport = require('passport');
var passportConf = require('../../passport-conf');

var apiOptions = {
    server : "http://localhost:3000"
};
if (process.env.NODE_ENV === 'production') {
    apiOptions.server = "";
}

// error handling function
var _showError = function (req, res, status, page) {
    var errTitle, content, page;
    if (status === 404) {
        errTitle = "404, page not found";
        content = "Oh dear. Looks like we can't find this page. Sorry.";
    } else {
        errTitle = status + ", something's gone wrong";
        content = "Something, somewhere, has gone just a little bit wrong.";
    }
    page = 'index';
    res.status(status);
    res.render(page, {
        errTitle : errTitle,
        errMessage : content
    });
};


// Request the SignUp page
module.exports.signupPageRender = (function (req, res) {
    if(req.user) return res.redirect('/dashboard');
    res.render('signup', {
        title: 'Emploi1Pro | Inscription',
        errors: req.flash('errors')
    });
});

// Request the Enterprise SignUp page
module.exports.businessSignupPageRender = (function (req, res) {
    if(req.user) return res.redirect('/dashboard');
    res.render('business-signup', {
        title: 'Inscription Entreprises | Emploi1Pro',
        errors: req.flash('errors')
    });
});


/*
module.exports.signUp = (function (req, res) {
    var requestOptions, path, postData;
    path='/api/users';
    postData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role
    };
    requestOptions = {
        url: apiOptions.server + path,
        method:"POST",
        json: postData
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 201) {
                res.redirect('login');
            }

            else {
                ///_showError(req, res, response.statusCode, 'signup');
                res.redirect('signup')
            }
        }
    )
});

module.exports.signUpCs = (function (req, res) {
    var requestOptions, path, postData;
    path='/api/consultants';
    postData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role
    };
    requestOptions = {
        url: apiOptions.server + path,
        method:"POST",
        json: postData
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 201) {
                res.redirect('login');
            }
                
            else {
                ///_showError(req, res, response.statusCode, 'signup');
                res.redirect('signup')
            }
        }
    )
});

module.exports.signUpEn = (function (req, res) {
    var requestOptions, path, postData;
    path='/api/enterprises';
    postData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role
    };
    requestOptions = {
        url: apiOptions.server + path,
        method:"POST",
        json: postData
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 201) {
                res.redirect('/login');
            }

            else {
                ///_showError(req, res, response.statusCode, 'signup');
                res.redirect('signup')
            }
        }
    )
});*/

// Request the Login page
module.exports.loginPageRender = (function (req, res) {
    if(req.user) return res.redirect('/dashboard');
    res.render('login', {title: 'Emploi1Pro | Connexion'});
});


module.exports.logOut = (function (req, res) {
    req.logout();
    res.redirect('/');
});

// Request the forgotten password page
module.exports.forgotten = (function (req, res) {
    res.render('forgotten-pass', {title: 'Emploi1Pro'});
});

// Request the renew password page
module.exports.renew = (function (req, res) {
    res.render('renew-pass', {title: 'Emploi1Pro'});
});