/**
 * Created by nokamojd on 06/09/2016.
 */

var request = require('request');
var methodOverride = require('method-override');



var apiOptions = {
    server : "http://localhost:3000"
};
if (process.env.NODE_ENV === 'production') {
    apiOptions.server = "";
}

// error handling function
var _showError = function (req, res, status) {
    var errTitle, content;
    if (status === 404) {
        errTitle = "404, page not found";
        content = "Oh dear. Looks like we can't find this page. Sorry.";
    } else {
        errTitle = status + ", something's gone wrong";
        content = "Something, somewhere, has gone just a little bit wrong.";
    }
    res.status(status);
    res.render('index', {
        errTitle : errTitle,
        content : content
    });
};


// Demands list page renderer
var renderDemandsPage = function (req, res, demandsAll) {
    if(!req.user) return res.redirect('/login');
    else if(req.user && req.user.user_role != '57b2e3f36a0c14cc080d2f64') return res.redirect('/denied');
    return res.render('dashboard/demands-table', {
        title: 'Dashboard - Demandes | Emploi1pro',
        demands: demandsAll
    })
};

// All demands request
module.exports.allDemands = (function (req, res) {
    var requestOptions, path;
    path = '/api/demands';
    requestOptions = {
        url : apiOptions.server + path,
        method : "GET",
        json : {}
    };
    request(
        requestOptions,
        function(err, response, body) {
            renderDemandsPage(req, res, body);
        }
    );
});

// Demands by author list page renderer
var renderDemandsByAuthorPage = function (req, res, responseBody) {
    if(!req.user) return res.redirect('/login');
    else if(req.user && req.user._id != req.params.id_user) return res.redirect('/denied');
    return res.render('dashboard/demands-table', {
        title: 'Dashboard - Demandes | Emploi1pro',
        demands: responseBody
    })
};

// All demands by author request
module.exports.allDemandsByAuthor = (function (req, res) {
    var requestOptions, path;
    path = '/api/demands/author/' + req.params.id_user;
    requestOptions = {
        url : apiOptions.server + path,
        method : "GET",
        json : {}
        //qs : {}
    };
    request(
        requestOptions,
        function(err, response, body) {
            renderDemandsByAuthorPage(req, res, body);
        }
    );
});

// Demand details renderer function
var renderDemandDetail = function (req, res, demand) {
    if(!req.user) return res.redirect('/login');
    else if(req.user && req.user.user_role != '57b2e3f36a0c14cc080d2f64' && req.user.user_role!='57b2e3f36a0c14cc080d2f63') return res.redirect('/denied');
    res.render('dashboard/demands-edit', {
        title: 'Dashboard - Demandes | Emploi1pro',
        demand: demand
    });
};

module.exports.getOneDemand = (function (req, res) {
    var requestOptions, path;
    path = '/api/demands/'+ req.params.id_demand;
    requestOptions = {
        url: apiOptions.server + path,
        method: "GET",
        json: {}
    };
    request(requestOptions,
        function(err, response, body){
            renderDemandDetail(req, res, body);
        }
    );
});


module.exports.getDemandForm = (function (req, res) {
    if(!req.user) return res.redirect('/login');
    else if(req.user && req.user.user_role != '57b2e3f36a0c14cc080d2f64' && req.user.user_role!='57b2e3f36a0c14cc080d2f63') return res.redirect('/denied');
    res.render('dashboard/demands-form', {
        title: 'Créer demande | Emploi1pro'
    });
});

module.exports.addDemand = (function (req, res) {
    var requestOptions, path, postData;
    path='/api/demands';
    postData = {
        dmdTitle: req.body.demand_t,
        dmdDescription: req.body.demand_desc,
        dmdDStartDate: req.body.demand_d_s_d,
        dmdSEndDate: req.body.demand_e_d,
        dmdConditions: req.body.demand_conds,
        dmdEstimatedBudget: req.body.demand_es_bgt,
        dmdLocation: req.body.demand_loc,
        dmdField: req.body.demand_fld,
        dmdRequiredSkills: req.body.demand_skills,
        dmdAuthor: req.body.demand_authr
    };
    requestOptions = {
        url: apiOptions.server + path,
        method:"POST",
        json: postData
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 201) {
                res.redirect('/dashboard/demands/u/'+ req.params.id_user);
            }
            else {
                _showError(req, res, response.statusCode);
            }
        }
    )
});


module.exports.updateDemand = (function (req, res) {
    var requestOptions, path, putData;
    path='/api/demands/'+ req.params.id_demand;
    putData = {
        dmdTitle: req.body.demand_t,
        dmdDescription: req.body.demand_desc,
        dmdDStartDate: req.body.demand_d_s_d,
        dmdSEndDate: req.body.demand_e_d,
        dmdConditions: req.body.demand_conds,
        dmdEstimatedBudget: req.body.demand_es_bgt,
        dmdLocation: req.body.demand_loc,
        dmdField: req.body.demand_loc,
        dmdRequiredSkills: req.body.demand_skills,
        dmdAuthor: req.body.demand_authr,
        dmdAvailability: req.body.is_available,
        dmdState: req.body.id_dmd_complete
    };
    requestOptions = {
        url: apiOptions.server + path,
        method:"PUT",
        json: putData
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 200) {
                res.redirect('/dashboard/demands/'+ req.params.id_demand);
            }
            else {
                _showError(req, res, response.statusCode);
            }
        }
    )
});

module.exports.deleteDemand = (function (req, res) {
    var requestOptions, path;
    path='/api/demands/'+ req.params.id_demand;
    requestOptions = {
        url: apiOptions.server + path,
        method:"DELETE",
        json: {}
    };
    request(
        requestOptions,
        function (err, response, body) {
            if(response.statusCode === 204) {
                if(req.user.user_role != '57b2e3f36a0c14cc080d2f64')
                    return res.redirect('/dashboard/demands/u/'+req.params.id_user);
                else
                    return res.redirect('/dashboard/demands')
            }
            else {
                _showError(req, res, response.statusCode);
            }
        }
    )
});