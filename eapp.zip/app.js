var express = require('express');
var path = require('path');
var util = require('util');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var bodyParser = require('body-parser');
var MongoStore = require('connect-mongo')(session); // store session on server storage
var passport = require('passport');
var flash = require('express-flash');
var methodOverride = require('method-override');
var bcrypt = require('bcrypt-nodejs');
var mongoose = require('mongoose');
var mongoosastic = require('mongoosastic');
require('./app_api/models/dbconfig');
var apiRoutes = require('./app_api/routes/index');
var routes = require('./app_server/routes/index');
var users = require('./app_server/routes/users');
var dashboard = require('./app_server/routes/dashboard');
var Field = require('./app_api/models/field.schema');
var Skill = require('./app_api/models/skill.schema');
var Role = require('./app_api/models/role.schema');
var User = require('./app_api/models/user.schema');
var cartLength = require('./app_server/middlewares/cart.lenght');
var offerApprovedReviews = require('./app_server/middlewares/offer.reviews.approved');
var nodemailer = require('nodemailer');
var app = express();


/*
// connection to the database through mongoose
var db = mongoose.createConnection('mongodb://root:37tcMuuuq@127.0.0.1:28018/admin');
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("we are connected to the db");
});*/


// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  resave: true,
  saveUninitialized: true,
  secret: "2ZviIunej4MnmsiVGJOBwNQSx8oOTWpg05nQo1nqK6DsAYJAn27bpJ1klk6QE0NSktrDByCTX8eBUHu4N4MbVuqBWx46HVW9p7ZEy12JOY1AHAGpSrx8Mv54mMMqDYMb",
  store: new MongoStore({url:"mongodb://epp:testepppdb@ds139645.mlab.com:39645/eappdb", auto_reconnect:true})
}));
app.use(flash());

app.use(methodOverride(function(req, res){
  if (req.body && typeof req.body === 'object' && '_method' in req.body) {
    // look in urlencoded POST bodies and delete it
    var method = req.body._method;
    delete req.body._method;
    return method
  }
}));
app.use(passport.initialize());
app.use(passport.session());

app.locals.moment = require('moment');

// function to call user data on multiple pages
app.use(function (req, res, next) {
  res.locals.user = req.user;
  next();
});

app.use(cartLength);
app.use(offerApprovedReviews);

/*
app.use(function (req, res, next) {
  User.find({}, function (err, usersU) {
    if(err) return next(err);
    res.locals.usersU = usersU;
  });
  next();
});
*/

// function to call fields data on multiple page
app.use(function (req, res, next) {
  Field.find({}, function (err, fields) {
    if(err) return next(err);
    res.locals.fields = fields;
    next();
  });
});

// function to call skills data on multiple page
app.use(function (req, res, next) {
  Skill.find({}, function (err, skills) {
    if(err) return next(err);
    res.locals.skills = skills;
    next();
  })
});

// function to call roles data on multiple page
app.use(function (req, res, next) {
  Role.find({}, function (err, roles) {
    if(err) return next(err);
    res.locals.roles = roles;
    next();
  });
});

app.use('/', routes);
app.use('/users', users);
app.use('/dashboard', dashboard);
app.use('/api', apiRoutes);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    //res.address(err.address || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  //res.address(err.address || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
